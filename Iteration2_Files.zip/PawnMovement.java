public class PawnMovement implements MovementStrategy {
    @Override
    public boolean isValid(Board board, Position from, Position to, Piece piece) {
        if (piece == null || piece.getType() != Piece.Type.P) return false;
        int dir = piece.getColor() == Piece.Color.WHITE ? -1 : 1;
        int expectedRow = from.getRow() + dir;
        return to.getCol() == from.getCol() && to.getRow() == expectedRow && board.getCell(to) == null;
    }
}

