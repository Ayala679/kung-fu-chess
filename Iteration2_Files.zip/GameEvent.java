public interface GameEvent {
    void execute(GameLogic logic);
}

