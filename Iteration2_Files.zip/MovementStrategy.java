public interface MovementStrategy {
    boolean isValid(Board board, Position from, Position to, Piece piece);
}

