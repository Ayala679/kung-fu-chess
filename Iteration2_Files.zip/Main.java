import java.util.Scanner;

/**
 * Main entry point - delegates everything to helper classes.
 */
public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        String[][] board = BoardParser.readBoard(input);

        if (!BoardValidator.isValid(board)) {
            input.close();
            return;
        }

        while (input.hasNextLine()) {
            String command = input.nextLine().trim();

            if (command.isEmpty()) {
                continue;
            }

            if (command.equals("print board")) {
                BoardValidator.printBoard(board);
            }
        }

        input.close();
    }
}

